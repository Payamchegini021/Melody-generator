"use client"

import type React from "react"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Shuffle, Settings } from "lucide-react"
import type { MelodyGenerationParams, ScaleType, AudioSettings } from "../types/music"
import { MusicTheory } from "../utils/music-theory"

interface ParameterControlsProps {
  params: MelodyGenerationParams
  audioSettings: AudioSettings
  onParamsChange: (params: Partial<MelodyGenerationParams>) => void
  onAudioSettingsChange: (settings: Partial<AudioSettings>) => void
  onGenerate: () => void
  isGenerating?: boolean
}

export const ParameterControls: React.FC<ParameterControlsProps> = ({
  params,
  audioSettings,
  onParamsChange,
  onAudioSettingsChange,
  onGenerate,
  isGenerating = false,
}) => {
  const scaleTypes: ScaleType[] = ["major", "minor", "dorian", "phrygian", "lydian", "mixolydian", "aeolian", "locrian"]
  const instrumentTypes = ["piano", "strings", "synth", "electric-piano"] as const
  const noteNames = MusicTheory.NOTE_NAMES

  const handleRandomizeParams = () => {
    const randomParams: Partial<MelodyGenerationParams> = {
      complexity: Math.random(),
      rhythmDensity: Math.random(),
      length: Math.floor(Math.random() * 8) + 1,
      scale: {
        ...params.scale,
        root: Math.floor(Math.random() * 12),
        type: scaleTypes[Math.floor(Math.random() * scaleTypes.length)],
      },
    }
    onParamsChange(randomParams)
  }

  return (
    <div className="bg-white border border-gray-300 rounded-lg shadow-lg p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Generation Parameters</h3>
        <Button variant="outline" size="sm" onClick={handleRandomizeParams} className="flex items-center gap-2">
          <Shuffle className="h-4 w-4" />
          Randomize
        </Button>
      </div>

      {/* Scale Selection */}
      <div className="space-y-3">
        <h4 className="font-medium text-gray-700">Scale</h4>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">Root Note</label>
            <Select
              value={noteNames[params.scale.root]}
              onValueChange={(value) => {
                const root = noteNames.indexOf(value)
                onParamsChange({
                  scale: { ...params.scale, root, notes: MusicTheory.createScale(root, params.scale.type).notes },
                })
              }}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {noteNames.map((note) => (
                  <SelectItem key={note} value={note}>
                    {note}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">Scale Type</label>
            <Select
              value={params.scale.type}
              onValueChange={(value: ScaleType) => {
                const scale = MusicTheory.createScale(params.scale.root, value)
                onParamsChange({ scale })
              }}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {scaleTypes.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type.charAt(0).toUpperCase() + type.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Generation Parameters */}
      <div className="space-y-4">
        <h4 className="font-medium text-gray-700">Melody Parameters</h4>

        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium text-gray-600">Length (measures)</label>
            <span className="text-sm font-mono text-gray-600">{params.length}</span>
          </div>
          <Slider
            value={[params.length]}
            onValueChange={(value) => onParamsChange({ length: value[0] })}
            min={1}
            max={16}
            step={1}
            className="w-full"
          />
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium text-gray-600">Complexity</label>
            <span className="text-sm font-mono text-gray-600">{Math.round(params.complexity * 100)}%</span>
          </div>
          <Slider
            value={[params.complexity]}
            onValueChange={(value) => onParamsChange({ complexity: value[0] })}
            min={0}
            max={1}
            step={0.01}
            className="w-full"
          />
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium text-gray-600">Rhythm Density</label>
            <span className="text-sm font-mono text-gray-600">{Math.round(params.rhythmDensity * 100)}%</span>
          </div>
          <Slider
            value={[params.rhythmDensity]}
            onValueChange={(value) => onParamsChange({ rhythmDensity: value[0] })}
            min={0}
            max={1}
            step={0.01}
            className="w-full"
          />
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium text-gray-600">Note Range</label>
            <span className="text-sm font-mono text-gray-600">
              {MusicTheory.midiToNoteName(params.range[0])} - {MusicTheory.midiToNoteName(params.range[1])}
            </span>
          </div>
          <Slider
            value={params.range}
            onValueChange={(value) => onParamsChange({ range: [value[0], value[1]] })}
            min={36}
            max={96}
            step={1}
            className="w-full"
          />
        </div>
      </div>

      {/* Audio Settings */}
      <div className="space-y-4 border-t pt-4">
        <h4 className="font-medium text-gray-700 flex items-center gap-2">
          <Settings className="h-4 w-4" />
          Audio Settings
        </h4>

        <div>
          <label className="block text-sm font-medium text-gray-600 mb-1">Instrument</label>
          <Select
            value={audioSettings.instrument}
            onValueChange={(value) => onAudioSettingsChange({ instrument: value as any })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {instrumentTypes.map((instrument) => (
                <SelectItem key={instrument} value={instrument}>
                  {instrument.charAt(0).toUpperCase() + instrument.slice(1).replace("-", " ")}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium text-gray-600">Volume</label>
            <span className="text-sm font-mono text-gray-600">{Math.round(audioSettings.volume * 100)}%</span>
          </div>
          <Slider
            value={[audioSettings.volume]}
            onValueChange={(value) => onAudioSettingsChange({ volume: value[0] })}
            min={0}
            max={1}
            step={0.01}
            className="w-full"
          />
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium text-gray-600">Reverb</label>
            <span className="text-sm font-mono text-gray-600">{Math.round(audioSettings.reverb * 100)}%</span>
          </div>
          <Slider
            value={[audioSettings.reverb]}
            onValueChange={(value) => onAudioSettingsChange({ reverb: value[0] })}
            min={0}
            max={1}
            step={0.01}
            className="w-full"
          />
        </div>
      </div>

      {/* Generate Button */}
      <Button onClick={onGenerate} disabled={isGenerating} className="w-full h-12 text-lg font-semibold" size="lg">
        {isGenerating ? (
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            Generating...
          </div>
        ) : (
          "Generate Melody"
        )}
      </Button>
    </div>
  )
}
