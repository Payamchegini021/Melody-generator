"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Save, Download, Share2, Trash2, FolderOpen } from "lucide-react"
import type { GeneratedMelody, ExportFormat } from "../types/music"
import { ExportManager } from "../utils/storage"

interface SaveExportControlsProps {
  currentMelody: GeneratedMelody | null
  savedMelodies: GeneratedMelody[]
  onSave: (melody: GeneratedMelody) => Promise<void>
  onLoad: (melody: GeneratedMelody) => void
  onDelete: (id: string) => Promise<void>
  onShare: (melody: GeneratedMelody) => Promise<string>
}

export const SaveExportControls: React.FC<SaveExportControlsProps> = ({
  currentMelody,
  savedMelodies,
  onSave,
  onLoad,
  onDelete,
  onShare,
}) => {
  const [isExporting, setIsExporting] = useState(false)
  const [exportFormat, setExportFormat] = useState<ExportFormat>("midi")
  const [melodyName, setMelodyName] = useState("")
  const [shareUrl, setShareUrl] = useState("")
  const [showSaveDialog, setShowSaveDialog] = useState(false)
  const [showLoadDialog, setShowLoadDialog] = useState(false)
  const [showShareDialog, setShowShareDialog] = useState(false)

  const exportFormats: { value: ExportFormat; label: string; description: string }[] = [
    { value: "midi", label: "MIDI", description: "Standard MIDI file format" },
    { value: "wav", label: "WAV", description: "High-quality audio" },
    { value: "mp3", label: "MP3", description: "Compressed audio" },
    { value: "musicxml", label: "MusicXML", description: "Music notation format" },
  ]

  const handleSave = async () => {
    if (!currentMelody) return

    const melodyToSave: GeneratedMelody = {
      ...currentMelody,
      name: melodyName || currentMelody.name,
      id: crypto.randomUUID(),
    }

    try {
      await onSave(melodyToSave)
      setMelodyName("")
      setShowSaveDialog(false)
    } catch (error) {
      console.error("Failed to save melody:", error)
    }
  }

  const handleExport = async () => {
    if (!currentMelody) return

    setIsExporting(true)
    try {
      const blob = await ExportManager.exportMelody(currentMelody, exportFormat)
      const url = URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.href = url
      link.download = `${currentMelody.name}.${exportFormat}`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error("Export failed:", error)
    } finally {
      setIsExporting(false)
    }
  }

  const handleShare = async () => {
    if (!currentMelody) return

    try {
      const url = await onShare(currentMelody)
      setShareUrl(url)
      setShowShareDialog(true)
    } catch (error) {
      console.error("Failed to share melody:", error)
    }
  }

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
    } catch (error) {
      console.error("Failed to copy to clipboard:", error)
    }
  }

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString() + " " + new Date(date).toLocaleTimeString()
  }

  return (
    <div className="bg-white border border-gray-300 rounded-lg shadow-lg p-6">
      <h3 className="text-lg font-semibold mb-4">Save & Export</h3>

      <div className="space-y-4">
        {/* Save Controls */}
        <div className="flex gap-2">
          <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" disabled={!currentMelody} className="flex items-center gap-2">
                <Save className="h-4 w-4" />
                Save
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Save Melody</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Melody Name</label>
                  <Input
                    value={melodyName}
                    onChange={(e) => setMelodyName(e.target.value)}
                    placeholder={currentMelody?.name || "Enter melody name..."}
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowSaveDialog(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleSave}>Save</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={showLoadDialog} onOpenChange={setShowLoadDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" className="flex items-center gap-2">
                <FolderOpen className="h-4 w-4" />
                Load
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Load Saved Melody</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {savedMelodies.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No saved melodies</p>
                ) : (
                  savedMelodies.map((melody) => (
                    <div key={melody.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">{melody.name}</h4>
                          <p className="text-sm text-gray-600">
                            {melody.notes.length} notes • {melody.params.length} measures •{" "}
                            {formatDate(melody.createdAt)}
                          </p>
                          <p className="text-xs text-gray-500">
                            {melody.params.scale.type} in {melody.params.scale.root}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => {
                              onLoad(melody)
                              setShowLoadDialog(false)
                            }}
                          >
                            Load
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => onDelete(melody.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </DialogContent>
          </Dialog>

          <Button variant="outline" onClick={handleShare} disabled={!currentMelody} className="flex items-center gap-2">
            <Share2 className="h-4 w-4" />
            Share
          </Button>
        </div>

        {/* Export Controls */}
        <div className="border-t pt-4">
          <h4 className="font-medium text-gray-700 mb-3">Export</h4>

          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-600 mb-1">Export Format</label>
              <Select value={exportFormat} onValueChange={(value: ExportFormat) => setExportFormat(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {exportFormats.map((format) => (
                    <SelectItem key={format.value} value={format.value}>
                      <div>
                        <div className="font-medium">{format.label}</div>
                        <div className="text-xs text-gray-500">{format.description}</div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button
              onClick={handleExport}
              disabled={!currentMelody || isExporting}
              className="w-full flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              {isExporting ? "Exporting..." : `Export as ${exportFormat.toUpperCase()}`}
            </Button>
          </div>
        </div>
      </div>

      {/* Share Dialog */}
      <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share Melody</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-gray-600">Share this link to let others listen to your melody:</p>
            <div className="flex gap-2">
              <Input value={shareUrl} readOnly className="flex-1" />
              <Button variant="outline" onClick={() => copyToClipboard(shareUrl)}>
                Copy
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
