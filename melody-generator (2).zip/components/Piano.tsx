"use client"

import type React from "react"
import { useState, useCallback, useRef, useEffect } from "react"
import type { Note } from "../types/music"

interface PianoProps {
  onNotePlay: (note: Note) => void
  onChordPlay: (notes: Note[]) => void
  activeNotes?: number[]
  octaves?: number
  startOctave?: number
}

export const Piano: React.FC<PianoProps> = ({
  onNotePlay,
  onChordPlay,
  activeNotes = [],
  octaves = 3,
  startOctave = 4,
}) => {
  const [pressedKeys, setPressedKeys] = useState<Set<number>>(new Set())
  const [isMouseDown, setIsMouseDown] = useState(false)
  const pianoRef = useRef<HTMLDivElement>(null)

  const isBlackKey = (noteIndex: number): boolean => {
    const keyPattern = [false, true, false, true, false, false, true, false, true, false, true, false]
    return keyPattern[noteIndex % 12]
  }

  const getKeyPosition = (keyIndex: number): { left: number; width: number } => {
    const whiteKeyWidth = 40
    const blackKeyWidth = 24
    const noteIndex = keyIndex % 12
    const octave = Math.floor(keyIndex / 12)

    if (isBlackKey(noteIndex)) {
      const whiteKeysBefore = [0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6][noteIndex]
      const left = octave * 7 * whiteKeyWidth + whiteKeysBefore * whiteKeyWidth - blackKeyWidth / 2
      return { left, width: blackKeyWidth }
    } else {
      const whiteKeyIndex = [0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6][noteIndex]
      const left = octave * 7 * whiteKeyWidth + whiteKeyIndex * whiteKeyWidth
      return { left, width: whiteKeyWidth }
    }
  }

  const handleKeyDown = useCallback(
    (midiNote: number) => {
      if (pressedKeys.has(midiNote)) return

      setPressedKeys((prev) => new Set(prev).add(midiNote))

      const note: Note = {
        pitch: midiNote,
        duration: 0.5,
        velocity: 80,
        startTime: 0,
      }

      onNotePlay(note)
    },
    [pressedKeys, onNotePlay],
  )

  const handleKeyUp = useCallback((midiNote: number) => {
    setPressedKeys((prev) => {
      const newSet = new Set(prev)
      newSet.delete(midiNote)
      return newSet
    })
  }, [])

  const handleMouseDown = useCallback(
    (midiNote: number) => {
      setIsMouseDown(true)
      handleKeyDown(midiNote)
    },
    [handleKeyDown],
  )

  const handleMouseUp = useCallback(() => {
    setIsMouseDown(false)
    setPressedKeys(new Set())
  }, [])

  const handleMouseEnter = useCallback(
    (midiNote: number) => {
      if (isMouseDown) {
        handleKeyDown(midiNote)
      }
    },
    [isMouseDown, handleKeyDown],
  )

  useEffect(() => {
    const handleGlobalMouseUp = () => setIsMouseDown(false)
    document.addEventListener("mouseup", handleGlobalMouseUp)
    return () => document.removeEventListener("mouseup", handleGlobalMouseUp)
  }, [])

  // Keyboard event handling
  useEffect(() => {
    const keyMap: { [key: string]: number } = {
      a: 60,
      w: 61,
      s: 62,
      e: 63,
      d: 64,
      f: 65,
      t: 66,
      g: 67,
      y: 68,
      h: 69,
      u: 70,
      j: 71,
      k: 72,
      o: 73,
      l: 74,
      p: 75,
      ";": 76,
    }

    const handleKeyDown = (event: KeyboardEvent) => {
      const midiNote = keyMap[event.key.toLowerCase()]
      if (midiNote && !pressedKeys.has(midiNote)) {
        handleKeyDown(midiNote)
      }
    }

    const handleKeyUp = (event: KeyboardEvent) => {
      const midiNote = keyMap[event.key.toLowerCase()]
      if (midiNote) {
        handleKeyUp(midiNote)
      }
    }

    document.addEventListener("keydown", handleKeyDown)
    document.addEventListener("keyup", handleKeyUp)

    return () => {
      document.removeEventListener("keydown", handleKeyDown)
      document.removeEventListener("keyup", handleKeyUp)
    }
  }, [pressedKeys, handleKeyDown, handleKeyUp])

  const renderKeys = () => {
    const keys = []
    const totalKeys = octaves * 12

    // Render white keys first
    for (let i = 0; i < totalKeys; i++) {
      const midiNote = startOctave * 12 + i
      if (!isBlackKey(i)) {
        const { left, width } = getKeyPosition(i)
        const isPressed = pressedKeys.has(midiNote)
        const isActive = activeNotes.includes(midiNote)

        keys.push(
          <div
            key={`white-${i}`}
            className={`absolute border border-gray-300 cursor-pointer select-none transition-colors duration-75 ${
              isPressed ? "bg-blue-200" : isActive ? "bg-yellow-200" : "bg-white hover:bg-gray-50"
            }`}
            style={{
              left: `${left}px`,
              width: `${width}px`,
              height: "120px",
              top: 0,
            }}
            onMouseDown={() => handleMouseDown(midiNote)}
            onMouseUp={() => handleMouseUp()}
            onMouseEnter={() => handleMouseEnter(midiNote)}
          >
            <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-xs text-gray-600">
              {midiNote % 12 === 0 ? `C${Math.floor(midiNote / 12) - 1}` : ""}
            </div>
          </div>,
        )
      }
    }

    // Render black keys on top
    for (let i = 0; i < totalKeys; i++) {
      const midiNote = startOctave * 12 + i
      if (isBlackKey(i)) {
        const { left, width } = getKeyPosition(i)
        const isPressed = pressedKeys.has(midiNote)
        const isActive = activeNotes.includes(midiNote)

        keys.push(
          <div
            key={`black-${i}`}
            className={`absolute cursor-pointer select-none transition-colors duration-75 z-10 ${
              isPressed ? "bg-blue-600" : isActive ? "bg-yellow-600" : "bg-gray-900 hover:bg-gray-700"
            }`}
            style={{
              left: `${left}px`,
              width: `${width}px`,
              height: "80px",
              top: 0,
            }}
            onMouseDown={() => handleMouseDown(midiNote)}
            onMouseUp={() => handleMouseUp()}
            onMouseEnter={() => handleMouseEnter(midiNote)}
          />,
        )
      }
    }

    return keys
  }

  return (
    <div className="bg-white border border-gray-300 rounded-lg shadow-lg p-4">
      <h3 className="text-lg font-semibold mb-4">Virtual Piano</h3>
      <div
        ref={pianoRef}
        className="relative bg-gray-100 rounded"
        style={{
          width: `${octaves * 7 * 40}px`,
          height: "120px",
        }}
      >
        {renderKeys()}
      </div>
      <div className="mt-2 text-sm text-gray-600">
        Use your computer keyboard: A-S-D-F-G-H-J-K-L or click/touch the keys
      </div>
    </div>
  )
}
