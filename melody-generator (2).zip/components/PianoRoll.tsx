"use client"

import type React from "react"
import { useRef, useEffect, useState, useCallback } from "react"
import type { Note } from "../types/music"
import { MusicTheory } from "../utils/music-theory"

interface PianoRollProps {
  notes: Note[]
  onNotesChange?: (notes: Note[]) => void
  playbackPosition?: number
  zoom?: number
  height?: number
  beatsPerMeasure?: number
  measures?: number
  minNote?: number
  maxNote?: number
  editable?: boolean
}

export const PianoRoll: React.FC<PianoRollProps> = ({
  notes,
  onNotesChange,
  playbackPosition = 0,
  zoom = 1,
  height = 400,
  beatsPerMeasure = 4,
  measures = 4,
  minNote = 48, // C3
  maxNote = 84, // C6
  editable = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [selectedNote, setSelectedNote] = useState<number | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(null)

  const noteHeight = 12
  const beatWidth = 60 * zoom
  const pianoWidth = 80
  const totalBeats = measures * beatsPerMeasure
  const canvasWidth = pianoWidth + totalBeats * beatWidth
  const noteRange = maxNote - minNote + 1
  const canvasHeight = noteRange * noteHeight

  const pixelToBeat = useCallback(
    (x: number): number => {
      return Math.max(0, (x - pianoWidth) / beatWidth)
    },
    [beatWidth, pianoWidth],
  )

  const beatToPixel = useCallback(
    (beat: number): number => {
      return pianoWidth + beat * beatWidth
    },
    [beatWidth, pianoWidth],
  )

  const pixelToNote = useCallback(
    (y: number): number => {
      const noteIndex = Math.floor(y / noteHeight)
      return maxNote - noteIndex
    },
    [noteHeight, maxNote],
  )

  const noteToPixel = useCallback(
    (note: number): number => {
      return (maxNote - note) * noteHeight
    },
    [noteHeight, maxNote],
  )

  const drawPianoRoll = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size
    canvas.width = canvasWidth
    canvas.height = canvasHeight

    // Clear canvas
    ctx.fillStyle = "#1a1a1a"
    ctx.fillRect(0, 0, canvasWidth, canvasHeight)

    // Draw piano keys
    ctx.fillStyle = "#2a2a2a"
    ctx.fillRect(0, 0, pianoWidth, canvasHeight)

    for (let i = 0; i < noteRange; i++) {
      const noteNumber = maxNote - i
      const y = i * noteHeight
      const isBlackKey = [1, 3, 6, 8, 10].includes(noteNumber % 12)

      // Key background
      ctx.fillStyle = isBlackKey ? "#1a1a1a" : "#f0f0f0"
      ctx.fillRect(2, y + 1, pianoWidth - 4, noteHeight - 2)

      // Key border
      ctx.strokeStyle = "#666"
      ctx.lineWidth = 1
      ctx.strokeRect(2, y + 1, pianoWidth - 4, noteHeight - 2)

      // Note name
      if (noteNumber % 12 === 0) {
        // C notes
        ctx.fillStyle = isBlackKey ? "#fff" : "#000"
        ctx.font = "10px Arial"
        ctx.textAlign = "center"
        ctx.fillText(MusicTheory.midiToNoteName(noteNumber), pianoWidth / 2, y + noteHeight / 2 + 3)
      }
    }

    // Draw grid
    ctx.strokeStyle = "#333"
    ctx.lineWidth = 1

    // Horizontal lines (notes)
    for (let i = 0; i <= noteRange; i++) {
      const y = i * noteHeight
      ctx.beginPath()
      ctx.moveTo(pianoWidth, y)
      ctx.lineTo(canvasWidth, y)
      ctx.stroke()
    }

    // Vertical lines (beats)
    for (let i = 0; i <= totalBeats; i++) {
      const x = pianoWidth + i * beatWidth
      ctx.strokeStyle = i % beatsPerMeasure === 0 ? "#555" : "#333"
      ctx.lineWidth = i % beatsPerMeasure === 0 ? 2 : 1
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, canvasHeight)
      ctx.stroke()
    }

    // Draw notes
    notes.forEach((note, index) => {
      const x = beatToPixel(note.startTime)
      const y = noteToPixel(note.pitch)
      const width = note.duration * beatWidth
      const noteHeight = 12

      // Note rectangle
      ctx.fillStyle = selectedNote === index ? "#ff6b6b" : "#4ecdc4"
      ctx.fillRect(x, y + 1, width, noteHeight - 2)

      // Note border
      ctx.strokeStyle = "#333"
      ctx.lineWidth = 1
      ctx.strokeRect(x, y + 1, width, noteHeight - 2)

      // Velocity indicator
      const velocityAlpha = note.velocity / 127
      ctx.fillStyle = `rgba(255, 255, 255, ${velocityAlpha * 0.5})`
      ctx.fillRect(x, y + 1, width, 2)
    })

    // Draw playback position
    if (playbackPosition > 0) {
      const x = beatToPixel(playbackPosition)
      ctx.strokeStyle = "#ff4444"
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, canvasHeight)
      ctx.stroke()
    }
  }, [
    notes,
    selectedNote,
    playbackPosition,
    canvasWidth,
    canvasHeight,
    beatWidth,
    pianoWidth,
    noteHeight,
    noteRange,
    totalBeats,
    beatsPerMeasure,
    beatToPixel,
    noteToPixel,
    maxNote,
  ])

  const handleMouseDown = useCallback(
    (event: React.MouseEvent<HTMLCanvasElement>) => {
      if (!editable) return

      const canvas = canvasRef.current
      if (!canvas) return

      const rect = canvas.getBoundingClientRect()
      const x = event.clientX - rect.left
      const y = event.clientY - rect.top

      if (x < pianoWidth) return // Clicked on piano keys

      const beat = pixelToBeat(x)
      const noteNumber = pixelToNote(y)

      // Check if clicking on existing note
      const clickedNoteIndex = notes.findIndex((note) => {
        const noteX = beatToPixel(note.startTime)
        const noteY = noteToPixel(note.pitch)
        const noteWidth = note.duration * beatWidth

        return x >= noteX && x <= noteX + noteWidth && y >= noteY && y <= noteY + noteHeight
      })

      if (clickedNoteIndex !== -1) {
        setSelectedNote(clickedNoteIndex)
        setIsDragging(true)
        setDragStart({ x, y })
      } else if (onNotesChange) {
        // Create new note
        const newNote: Note = {
          pitch: noteNumber,
          duration: 0.5,
          velocity: 80,
          startTime: Math.round(beat * 4) / 4, // Snap to 16th notes
        }

        const newNotes = [...notes, newNote]
        onNotesChange(newNotes)
        setSelectedNote(newNotes.length - 1)
      }
    },
    [
      editable,
      notes,
      pianoWidth,
      pixelToBeat,
      pixelToNote,
      beatToPixel,
      noteToPixel,
      beatWidth,
      noteHeight,
      onNotesChange,
    ],
  )

  const handleMouseMove = useCallback(
    (event: React.MouseEvent<HTMLCanvasElement>) => {
      if (!isDragging || !dragStart || selectedNote === null || !onNotesChange) return

      const canvas = canvasRef.current
      if (!canvas) return

      const rect = canvas.getBoundingClientRect()
      const x = event.clientX - rect.left
      const y = event.clientY - rect.top

      const beat = pixelToBeat(x)
      const noteNumber = pixelToNote(y)

      const updatedNotes = [...notes]
      updatedNotes[selectedNote] = {
        ...updatedNotes[selectedNote],
        startTime: Math.max(0, Math.round(beat * 4) / 4),
        pitch: Math.max(minNote, Math.min(maxNote, noteNumber)),
      }

      onNotesChange(updatedNotes)
    },
    [isDragging, dragStart, selectedNote, notes, pixelToBeat, pixelToNote, minNote, maxNote, onNotesChange],
  )

  const handleMouseUp = useCallback(() => {
    setIsDragging(false)
    setDragStart(null)
  }, [])

  const handleKeyDown = useCallback(
    (event: KeyboardEvent) => {
      if (!editable || selectedNote === null || !onNotesChange) return

      if (event.key === "Delete" || event.key === "Backspace") {
        const updatedNotes = notes.filter((_, index) => index !== selectedNote)
        onNotesChange(updatedNotes)
        setSelectedNote(null)
      }
    },
    [editable, selectedNote, notes, onNotesChange],
  )

  useEffect(() => {
    drawPianoRoll()
  }, [drawPianoRoll])

  useEffect(() => {
    document.addEventListener("keydown", handleKeyDown)
    return () => document.removeEventListener("keydown", handleKeyDown)
  }, [handleKeyDown])

  return (
    <div className="bg-gray-900 rounded-lg p-4 overflow-auto">
      <h3 className="text-white text-lg font-semibold mb-4">Piano Roll</h3>
      <div className="relative">
        <canvas
          ref={canvasRef}
          className="border border-gray-600 cursor-crosshair"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          style={{ maxWidth: "100%", height: `${Math.min(height, canvasHeight)}px` }}
        />
        {editable && (
          <div className="mt-2 text-sm text-gray-400">
            Click to add notes, drag to move, Delete to remove selected note
          </div>
        )}
      </div>
    </div>
  )
}
