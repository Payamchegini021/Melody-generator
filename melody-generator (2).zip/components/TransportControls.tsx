"use client"

import type React from "react"
import { Play, Pause, Square, RotateCcw, Repeat } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import type { TransportState } from "../types/music"

interface TransportControlsProps {
  transportState: TransportState
  onPlay: () => void
  onPause: () => void
  onStop: () => void
  onReset: () => void
  onBpmChange: (bpm: number) => void
  onLoopToggle: () => void
  disabled?: boolean
}

export const TransportControls: React.FC<TransportControlsProps> = ({
  transportState,
  onPlay,
  onPause,
  onStop,
  onReset,
  onBpmChange,
  onLoopToggle,
  disabled = false,
}) => {
  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = Math.floor(seconds % 60)
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  return (
    <div className="bg-white border border-gray-300 rounded-lg shadow-lg p-6">
      <h3 className="text-lg font-semibold mb-4">Transport Controls</h3>

      {/* Main Controls */}
      <div className="flex items-center justify-center gap-2 mb-6">
        <Button variant="outline" size="icon" onClick={onReset} disabled={disabled} className="h-12 w-12">
          <RotateCcw className="h-5 w-5" />
        </Button>

        <Button variant="outline" size="icon" onClick={onStop} disabled={disabled} className="h-12 w-12">
          <Square className="h-5 w-5" />
        </Button>

        <Button
          variant={transportState.isPlaying ? "default" : "outline"}
          size="icon"
          onClick={transportState.isPlaying ? onPause : onPlay}
          disabled={disabled}
          className="h-14 w-14"
        >
          {transportState.isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
        </Button>

        <Button
          variant={transportState.loop ? "default" : "outline"}
          size="icon"
          onClick={onLoopToggle}
          disabled={disabled}
          className="h-12 w-12"
        >
          <Repeat className="h-5 w-5" />
        </Button>
      </div>

      {/* Time Display */}
      <div className="text-center mb-4">
        <div className="text-2xl font-mono font-bold text-gray-800">{formatTime(transportState.currentTime)}</div>
        <div className="text-sm text-gray-600">
          {transportState.isPlaying ? "Playing" : transportState.isPaused ? "Paused" : "Stopped"}
        </div>
      </div>

      {/* BPM Control */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-sm font-medium text-gray-700">Tempo (BPM)</label>
          <span className="text-sm font-mono text-gray-600">{Math.round(transportState.bpm)}</span>
        </div>

        <Slider
          value={[transportState.bpm]}
          onValueChange={(value) => onBpmChange(value[0])}
          min={60}
          max={200}
          step={1}
          disabled={disabled}
          className="w-full"
        />

        <div className="flex justify-between text-xs text-gray-500">
          <span>60</span>
          <span>130</span>
          <span>200</span>
        </div>
      </div>

      {/* Status Indicators */}
      <div className="mt-4 flex justify-center gap-4 text-xs">
        <div className={`flex items-center gap-1 ${transportState.loop ? "text-blue-600" : "text-gray-400"}`}>
          <div className={`w-2 h-2 rounded-full ${transportState.loop ? "bg-blue-600" : "bg-gray-300"}`} />
          Loop
        </div>
        <div className={`flex items-center gap-1 ${transportState.isPlaying ? "text-green-600" : "text-gray-400"}`}>
          <div className={`w-2 h-2 rounded-full ${transportState.isPlaying ? "bg-green-600" : "bg-gray-300"}`} />
          Playing
        </div>
      </div>
    </div>
  )
}
