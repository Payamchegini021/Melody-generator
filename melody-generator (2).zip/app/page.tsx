import MelodyGeneratorApp from "../melody-generator"

export default function Page() {
  return <MelodyGeneratorApp />
}
