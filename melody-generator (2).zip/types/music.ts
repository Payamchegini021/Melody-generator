export interface Note {
  pitch: number // MIDI note number (0-127)
  duration: number // In beats
  velocity: number // 0-127
  startTime: number // In beats
}

export interface Chord {
  root: number
  type: ChordType
  inversion: number
}

export interface Scale {
  root: number
  type: ScaleType
  notes: number[]
}

export interface MelodyGenerationParams {
  length: number // Number of measures
  complexity: number // 0-1
  rhythmDensity: number // 0-1
  range: [number, number] // [min, max] MIDI notes
  scale: Scale
  chordProgression?: Chord[]
}

export interface GeneratedMelody {
  id: string
  notes: Note[]
  params: MelodyGenerationParams
  createdAt: Date
  name: string
}

export type ChordType = "major" | "minor" | "diminished" | "augmented" | "sus2" | "sus4" | "maj7" | "min7" | "dom7"
export type ScaleType = "major" | "minor" | "dorian" | "phrygian" | "lydian" | "mixolydian" | "aeolian" | "locrian"
export type InstrumentType = "piano" | "strings" | "synth" | "electric-piano"
export type ExportFormat = "midi" | "wav" | "mp3" | "musicxml"

export interface AudioSettings {
  instrument: InstrumentType
  volume: number
  reverb: number
  attack: number
  decay: number
  sustain: number
  release: number
}

export interface TransportState {
  isPlaying: boolean
  isPaused: boolean
  currentTime: number
  bpm: number
  loop: boolean
}
